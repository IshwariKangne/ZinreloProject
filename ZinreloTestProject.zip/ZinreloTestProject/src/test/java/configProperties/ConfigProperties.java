package configProperties;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigProperties {
	private static String browser;
	private static String url;
	private static String username;
	private static String password;

	public static void setProperties() throws IOException, InterruptedException {

		// Read properties file
		Properties prop = new Properties();
		FileInputStream inputstream = new FileInputStream("./config.properties/configdata.properties");
		prop.load(inputstream);

		// set the all value using properties file
		browser=prop.getProperty("Browser");
		url = prop.getProperty("Url");
		username = prop.getProperty("Username");
		password = prop.getProperty("Password");
	}
	
	/**
	 * get Browser  
	 */
	public static String getBrowser() {
		return browser;
	
	}
	/**
	 * get URL  
	 */
	public static String getUrl() {
		return url;
	}

	/**
	 * get USERNAME  
	 */
	public static String getUsername() {
		return username;
	}

	/**
	 * get PASSWORD  
	 */
	public static String getPassword() {
		return password;
	}
}