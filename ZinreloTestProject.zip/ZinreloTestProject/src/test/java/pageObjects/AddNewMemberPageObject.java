package pageObjects;

import org.openqa.selenium.By;

import commanFunctions.CommonConstants;
import commanFunctions.Log;

public class AddNewMemberPageObject extends PageObject {
	By addNewMember = By.id("add_new_member");
	By newEmailId = By.id("user_email");
	By firstName = By.id("first_name");
	By lastName = By.id("last_name");
	By memberId = By.id("merchant_user_id");
	By addButton = By.id("enroll_user_proceed");
	By successMessage = By.xpath("(//div[contains(@class, 'modal-body')])[2]/span");
	By okButton = By.id("enroll_user_success");
	By searchInputBox = By.xpath("//input[@type='text' and contains(@class, 'search_user_input')]");
	By searchButton = By.id("search");
	By searchNewMember = By.xpath("//tr[@class='user_row']/td[2]/span");
	By warningMessage = By.xpath("//div[contains(@class, 'alert alert-danger')]/span");
	By popupCloseButton = By.id("modal_close");

	/**
	 * Click on new add member tab
	 * @throws InterruptedException 
	 */
	public void clickAddMember() throws InterruptedException {
		staticWait(2000);
		waitForElementToBeClickable(addNewMember);
		click(getWebElement(addNewMember));
	}

	/**
	 * Click on close pop Up button
	 */
	public void clickPopupCloseButton() {
		click(getWebElement(popupCloseButton));
	}

	/**
	 * Click on Add button
	 */
	public void clickOnAddButton() {
		click(getWebElement(addButton));
	}

	/**
	 * Click on OK button
	 */
	public void clickOnOkButton() {
		click(getWebElement(okButton));
	}

	/**
	 * Click on search button
	 * @throws InterruptedException 
	 */
	public void clickOnSearch() throws InterruptedException {
		staticWait(2000);
		waitForElementToBeClickable(searchButton);
		click(getWebElement(searchButton));
		staticWait(1000);
	}

	/**
	 * Enter value in field email ID inputBox
	 */
	public void setEmailId(String newEmailValue) {
		waitForElement(newEmailId);
		enterText(getWebElement(newEmailId), newEmailValue);
	}

	/**
	 * Enter value in field firstName inputBox
	 */
	public void setFirstName(String firstNameValue) {
		waitForElement(firstName);
		enterText(getWebElement(firstName), firstNameValue);
	}

	/**
	 * Enter value in field lastName inputBox
	 */
	public void setLastName(String lastNameValue) {
		waitForElement(lastName);
		enterText(getWebElement(lastName), lastNameValue);
	}

	/**
	 * Enter value in field MemberID inputBox
	 */
	public void setMemberId(String memberIdValue) {
		waitForElement(memberId);
		enterText(getWebElement(memberId), memberIdValue);
	}

	/**
	 * Enter value in field search inputBox
	 * @throws InterruptedException 
	 */
	public void setSearchInputBox(String newEmailValue) throws InterruptedException {
		waitForElementToBeClickable(searchInputBox);
		enterText(getWebElement(searchInputBox), newEmailValue);
	}

	/**
	 * get success message
	 */
	public String getSuccessMessage() {
		waitForElement(successMessage);
		return getWebElement(successMessage).getText();
	}

	/**
	 * get warning message
	 */
	public String getWarningMessage() {
		waitForElement(warningMessage);
		return getWebElement(warningMessage).getText();
	}

	/**
	 * get text for first search result
	 */
	public String getSearchResult(String value) {
		waitForTextToBePresentInElement(searchNewMember, value);
		return getWebElement(searchNewMember).getText();
	}

	/**
	 * Add new member with given details
	 * @throws InterruptedException 
	 */
	public void addNewMember(String newEmailValue, String firstName, String lastName, String memberId,
			boolean errorExpected) throws InterruptedException {

		clickAddMember();
		// add all details for member
		if (newEmailValue != "" || newEmailValue != null)
			setEmailId(newEmailValue);

		if (firstName != "" || firstName != null)
			setFirstName(firstName);

		if (lastName != "" || lastName != null)
			setLastName(lastName);

		if (memberId != "" || memberId != null)
			setMemberId(memberId);

		clickOnAddButton();

		// verify success message
		if (!errorExpected) {
			String actualMessage = getSuccessMessage();
			String expectedMessage = firstName + " " + lastName + " (" + newEmailValue + ") "
					+ CommonConstants.SUCCESS_MESSAGE;
			
			if(actualMessage.equals(expectedMessage)){
				Log.info("New Member added successfully...");
			}
			else{
				Log.info("New Member was not added successfully...");
				softAssert.assertTrue(false);
			}
			clickOnOkButton();
		}
	}

	/**
	 * Search newly created member with email ID
	 * 
	 * @throws InterruptedException
	 */
	public void searchMember(String newEmailValue) throws InterruptedException {
		setSearchInputBox(newEmailValue);
		clickOnSearch();

		// verify newly created member searched successfully
		String actualSearchResult = getSearchResult(newEmailValue);
		String expectedSearchResult = newEmailValue;
		
		if (actualSearchResult.equals(expectedSearchResult)){
			Log.info("New Member searched successfully...");
		}
		else{
			Log.info("New Member was not searched successfully...");
			softAssert.assertTrue(false);
		}
		
	}

	public void verifyWarningMessage(String expectedMessage) {

		// verify warning message displayed
		String actualMessage = getWarningMessage();
		softAssert.assertEquals(actualMessage, expectedMessage);
		if (actualMessage.equals(expectedMessage)){
			Log.info("Warning successfully verified and expected message displayed '" + expectedMessage + "'");
		}
		else{
			Log.info("Warning was not successfully verified and expected message displayed '" + expectedMessage + "'");
			softAssert.assertTrue(false);
		}
	}

}