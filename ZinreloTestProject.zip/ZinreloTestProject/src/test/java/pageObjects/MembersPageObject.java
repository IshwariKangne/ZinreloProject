package pageObjects;

import org.openqa.selenium.By;

public class MembersPageObject extends PageObject {
	By membersTab = By.id("customers_tab");

	/**
	 * Click on members tab
	 */
	public void clickMembersTab() {
		click(getWebElement(membersTab));
	}

}
