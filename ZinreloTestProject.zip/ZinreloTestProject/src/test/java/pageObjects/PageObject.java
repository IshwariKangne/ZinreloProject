package pageObjects;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import commanFunctions.Log;
import configProperties.ConfigProperties;

public class PageObject {
	private static WebDriver driver;
	public static WebDriverWait wait;
	public static SoftAssert softAssert;
	public static void getDriver() {
		
		//Open Chrome browser
		if (ConfigProperties.getBrowser().toLowerCase().equals("chrome")) {
			System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
			System.out.println("Starting chrome browser...");
			driver = new ChromeDriver();
		}

		//Open Firefox browser
		if (ConfigProperties.getBrowser().toLowerCase().equals("firefox")) {
			System.setProperty("webdriver.gecko.driver","./drivers/geckodriver.exe");
			System.out.println("Starting Firefox browser...");
			driver = new FirefoxDriver();
		}

		//Open IE browser
		if (ConfigProperties.getBrowser().toLowerCase().equals("ie")) {
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
			System.setProperty("webdriver.ie.driver","./drivers/IEDriverServer.exe");
			Log.info("Starting IE browser...");
			driver = new InternetExplorerDriver();
		}
		
		////Maximizes the browser window
		driver.manage().window().maximize();
		
		//Given implicit wait for each WebElement
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

		// Initialize explicit wait
		wait = new WebDriverWait(driver, 15);
		
		//Initialize soft assert
		softAssert = new SoftAssert();
	}
	
	/**
	 * Open with given URL
	 */
	public static void navigateToUrl(String url) {
		driver.get(url);
	}

	/**
	 * Given explicit wait for a WebElement
	 */
	public void waitForElement(By locator) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	/**
	 * Given explicit wait for a WebElement
	 */
	public void waitForElementToBeClickable(By locator) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}
	
	/**
	 * Given explicit wait for a WebElement
	 */
	public void waitForTextToBePresentInElement(By locator, String text) {
		wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
	}

	/**
	 * get WebElement using locator
	 */
	public WebElement getWebElement(By locator) {
		return driver.findElement(locator);
	}
	
	/**
	 * get WebElement using locator
	 */
	public List<WebElement> getWebElements(By locator) {
		return driver.findElements(locator);
	}

	/**
	 * Click on WebElement present on browser page
	 */
	public void click(WebElement element) {
		if (ConfigProperties.getBrowser().toLowerCase().equals("ie")) {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", element);
		}
		else{
			element.click();
		}
	}

	/**
	 * Enter text value with given data
	 */
	public void enterText(WebElement element, String value) {
		element.sendKeys(value);
	}
	
	/**
	 * Verify if element is displayed
	 */
	public boolean isDisplayed(List<WebElement> list) {
		if (list.size() > 0)
			return true;
		else
			return false;
	}

	/**
	 * Close all browser tabs
	 */
	public static void closeBrowser() {
		driver.quit();
	}
	
	/**
	 * static wait, use only if required
	 * @throws InterruptedException 
	 */
	public static void staticWait(long millis) throws InterruptedException {
		Thread.sleep(millis);
	}
	
	public static void turnOffImplicitWaits() {
	    driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
	}

	public static void turnOnImplicitWaits() {
	    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

}
