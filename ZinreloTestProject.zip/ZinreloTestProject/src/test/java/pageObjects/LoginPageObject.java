package pageObjects;

import org.openqa.selenium.By;

import configProperties.ConfigProperties;

public class LoginPageObject extends PageObject {
	static By email = By.id("id_email");
	static By password = By.id("id_password");
	By loginButton = By.xpath("//button[@id='id_login_button']");
	By logoutButton = By.xpath("//a[contains(text(),'Logout')]");
	

	/**
	 * Enter email address
	 */
	public void setEmail(String emailValue) {
		enterText(getWebElement(email), emailValue);
	}

	/**
	 * Enter password
	 */
	public void setPassword(String passwordValue) {
		enterText(getWebElement(password), passwordValue);
	}

	/**
	 * Click on login button
	 */
	public void clickOnLoginButton() {
		click(getWebElement(loginButton));
	}
	
	/**
	 * Verify logout button if displayed
	 */
	public boolean isDisplayedLogoutButton() {
		return isDisplayed(getWebElements(logoutButton));
	}

	/**
	 * Function written to login to the Zinrelo application
	 */
	public void loginToApplication() {

		// login to ZinreloApplication
		PageObject.navigateToUrl(ConfigProperties.getUrl());
		
		turnOffImplicitWaits();
		if (!isDisplayedLogoutButton()){
			setEmail(ConfigProperties.getUsername());
			setPassword(ConfigProperties.getPassword());
			clickOnLoginButton();
		}
		turnOnImplicitWaits();
	}
}
