package commanFunctions;

import java.sql.Timestamp;

public class CommonFunctions {

	public String getUniqueString() {
		
		/**
		 * Get random text
		 */
		String generatedUniqueString = String.valueOf(System.currentTimeMillis());
		return generatedUniqueString;
	}
	
	/**
	 * Get current timeStamp
	 */
	public static String getCurrentTime() {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		return String.valueOf(timestamp);
	}
}
