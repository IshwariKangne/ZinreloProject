package commanFunctions;

public class CommonConstants {

	// All constants defined here
	public static String SUCCESS_MESSAGE = "has been enrolled successfully.";
	public static String WARNING_MESSAGE_EXISTING_EMAILID = "Member already exists.";
	public static String WARNING_INVALID_EMAILID = "Email has to be valid email address. Please fix this error to proceed.";
	public static String BLANK_VALUE = "";
	public static String WARNING_EMAILID_BLANK = "Email seems to be blank. Please fix this error to proceed.";
	public static String WARNING_FIRSTNAME_BLANK = "First Name seems to be blank. Please fix this error to proceed.";
}
