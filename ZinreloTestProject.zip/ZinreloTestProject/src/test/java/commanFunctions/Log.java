package commanFunctions;

public class Log {
	/*
	 * This function will write logs for the test case
	 */
	public static void info(String log){
		System.out.println(CommonFunctions.getCurrentTime()+": Step: "+log);
	}

}
