package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilities {
	public static String[][] readExcel() throws IOException {

		// Read Excel data sheet
		File file1 = new File("./data/ZinreloData.xlsx");
		FileInputStream inputstream = new FileInputStream(file1);
		XSSFWorkbook ws = new XSSFWorkbook(inputstream);
		XSSFSheet sh = ws.getSheetAt(0);
		int rowCount = sh.getLastRowNum();
		int colCount = sh.getRow(0).getLastCellNum();
		String excelData[][] = new String[rowCount+1][colCount];
		//read data from excel and save it
		for (int i = 0; i <= rowCount; i++) {
			for (int j = 0; j < colCount; j++) {
				try {
					excelData[i][j] = String.valueOf(sh.getRow(i).getCell(j).getStringCellValue());
				} catch (Exception e) {
					excelData[i][j] = String.valueOf(sh.getRow(i).getCell(j).getNumericCellValue());
				}
			}
		}

		ws.close();
		return excelData;
	}
}
