package zinreloTests;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import commanFunctions.CommonConstants;
import commanFunctions.CommonFunctions;
import commanFunctions.Log;
import configProperties.ConfigProperties;
import pageObjects.AddNewMemberPageObject;
import pageObjects.LoginPageObject;
import pageObjects.MembersPageObject;
import pageObjects.PageObject;
import utilities.ExcelUtilities;

public class LoginZinrelo {

	@BeforeMethod
	public void beforeMethod() throws IOException, InterruptedException {
		LoginPageObject loginPageObject = new LoginPageObject();

		// Open Browser
		ConfigProperties.setProperties();
		PageObject.getDriver();
		
		// Login to the Zinrelo Application
		Log.info("Loading 'Zinrelo | Zing your Loyalty and Referral programs' Site...");
		loginPageObject.loginToApplication();
	}

	@DataProvider
	public Object[][] testData() throws IOException {

		// Read data from excel sheet
		String RegCred[][] = ExcelUtilities.readExcel();
		return RegCred;
	}

	@Test(dataProvider = "testData", priority=1 /*, enabled=false*/)
	public void createNewMemberAndsearchOnMembersTab(String emailSuffix, String firstName, String lastName, String memberId)
	{
		try{
			CommonFunctions commonFunctions = new CommonFunctions();
	
			// Click Members Tab
			Log.info("Click on Members Tab");
			MembersPageObject memberspageobject = new MembersPageObject();
			memberspageobject.clickMembersTab();
	
			// Add new member
			Log.info("Creating new member...");
			String newEmail = "z" + commonFunctions.getUniqueString() + emailSuffix;
			AddNewMemberPageObject addNewMemberPageObject = new AddNewMemberPageObject();
			addNewMemberPageObject.addNewMember(newEmail, firstName, lastName, memberId,false);
	
			// Search newly created member
			Log.info("Search newly created member");
			addNewMemberPageObject.searchMember(newEmail);
		}catch(Exception e){
			PageObject.softAssert.assertTrue(false);
			Log.info(e.getMessage());
		}
		finally{
			PageObject.softAssert.assertAll();
		}
	}
	
	@Test(dataProvider = "testData" , priority=2/*enabled = false*/)
	public void createNewMemberWithExistingEmaiIdAndVerifyWarningMessage(String emailSuffix, String firstName, String lastName, String memberId)
	{
		try{
			CommonFunctions commonFunctions = new CommonFunctions();
			
			// Click Members Tab
			Log.info("Click on Members Tab");
			MembersPageObject memberspageobject = new MembersPageObject();
			memberspageobject.clickMembersTab();
	
			// Add new member
			Log.info("Creating a new member..");
			String newEmail = "z" + commonFunctions.getUniqueString() + emailSuffix;
			AddNewMemberPageObject addNewMemberPageObject = new AddNewMemberPageObject();
			addNewMemberPageObject.addNewMember(newEmail, firstName, lastName, memberId, false);
			Log.info("Creating a new member with existing email Id...");
			addNewMemberPageObject.addNewMember(newEmail, firstName, lastName, memberId, true);
			
			//verify email already exist warning message displayed
			Log.info("Verify warning message displayed");
			addNewMemberPageObject.verifyWarningMessage(CommonConstants.WARNING_MESSAGE_EXISTING_EMAILID);
		}catch(Exception e){
			PageObject.softAssert.assertTrue(false);
			Log.info(e.getMessage());
		}
		finally{
			PageObject.softAssert.assertAll();
		}
	}
	
	@Test(dataProvider = "testData", priority=3/*, enabled = false*/)
	public void createNewMemberWithInvalidEmailIdAndVerifyWarningMessage(String invalidEmail, String firstName, String lastName, String memberId)
	{
		try{
			// Click Members Tab
			Log.info("Click on Members Tab");
			MembersPageObject memberspageobject = new MembersPageObject();
			memberspageobject.clickMembersTab();
	
			// Add new member
			Log.info("Creating new member with invalid email id...");
			AddNewMemberPageObject addNewMemberPageObject = new AddNewMemberPageObject();
			addNewMemberPageObject.addNewMember(invalidEmail, firstName, lastName, memberId, true);
			
			//verify invalid email id entered warning message displayed
			Log.info("Verify warning message displayed");
			addNewMemberPageObject.verifyWarningMessage(CommonConstants.WARNING_INVALID_EMAILID);
		}catch(Exception e){
			PageObject.softAssert.assertTrue(false);
			Log.info(e.getMessage());
		}
		finally{
			PageObject.softAssert.assertAll();
		}
	}
	
	@Test(dataProvider = "testData", priority=4 /*, enabled=false*/)
	public void createNewMemberWithBlankMandatoryFieldsAndVerifyWarningMessage(String emailSuffix, String firstName, String lastName, String memberId)
	{
		try{
			CommonFunctions commonFunctions = new CommonFunctions();
			
			// Click Members Tab
			Log.info("Click on Members Tab");
			MembersPageObject memberspageobject = new MembersPageObject();
			memberspageobject.clickMembersTab();
	
			// Add new member
			Log.info("Creating new member with blank email id...");
			String newEmail = "z" + commonFunctions.getUniqueString() + emailSuffix;
			AddNewMemberPageObject addNewMemberPageObject = new AddNewMemberPageObject();
			addNewMemberPageObject.addNewMember(CommonConstants.BLANK_VALUE, firstName, lastName, memberId, true);
			
			//verify blank email id field entered warning message displayed
			Log.info("Verify warning message displayed");
			addNewMemberPageObject.verifyWarningMessage(CommonConstants.WARNING_EMAILID_BLANK);
			
			// click on close button pop_up
			addNewMemberPageObject.clickPopupCloseButton();
			Log.info("creating new member with blank first name...");
			addNewMemberPageObject.addNewMember(newEmail, CommonConstants.BLANK_VALUE, lastName, memberId, true);
			
			//verify first name field blank entered warning message displayed
			Log.info("Verify warning message displayed");
			addNewMemberPageObject.verifyWarningMessage(CommonConstants.WARNING_FIRSTNAME_BLANK);
		}catch(Exception e){
			PageObject.softAssert.assertTrue(false);
			Log.info(e.getMessage());
		}
		finally{
			PageObject.softAssert.assertAll();
		}
	}
	
	@AfterMethod
	public void afterMethod() {
		// Close Browser
		PageObject.closeBrowser();
	}
}
